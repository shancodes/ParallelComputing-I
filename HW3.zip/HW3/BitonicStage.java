import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;

/**
 * A thread-runnable Bitonic Sorter. Includes recursive implementation of BitonicSort and BitonicMerge
 * Implements Runnable
 */
public class BitonicStage implements Runnable
{
    private SynchronousQueue<double[]> input1, input2, output;
    private String name;
    private int timeout = 1;

    /**
     * Constructor that takes one argument for input array size
     * @param n - input array size
     */
    public BitonicStage(int n) {
        this.size = n;
        this.output_size = 2 * n;
    }

    /**
     * Constructor with input and output queues and size for input arrays
     * @param input1 - input SynchronousQueue
     * @param input2 - input SynchronousQueue
     * @param output - output SynchronousQueue
     * @param n - length of the input arrays
     */
    public BitonicStage(SynchronousQueue<double[]> input1,
                        SynchronousQueue<double[]> input2,
                        SynchronousQueue<double[]> output,
                        int n) {
        this.input1 = input1;
        this.input2 = input2;
        this.output = output;
        this.size = n;
        this.output_size = 2 * n;
    }

    /**
     * Constructor with name for the thread
     * @param input1 - input SynchronousQueue
     * @param input2 - input SynchronousQueue
     * @param output - output SynchronousQueue
     * @param name - name of the thread, determines direction of BitonicSort
     * @param n - length of the input arrays
     */
    public BitonicStage(SynchronousQueue<double[]> input1,
                        SynchronousQueue<double[]> input2,
                        SynchronousQueue<double[]> output,
                        String name, int n) {
        this.name = name;
        this.input1 = input1;
        this.input2 = input2;
        this.output = output;
        this.size = n;
        this.output_size = 2 * n;
    }

    double[] mergedSequence; // Output array
    int size = 0, output_size = 0;

    /**
     * Process method that takes in direction argument
     * @param var1 - input array 1
     * @param var2 - input array 2
     * @param dir - direction; 1 for UP and 0 for DOWN
     * @return output array
     */
    public double[] process(double[] var1, double[] var2, int dir) {
        Merge(var1,var2);
        BitonicSort(0, output_size, dir);

        return mergedSequence;
    }

    /**
     * Process method - called from thread run() method
     * @param var1 - input array 1
     * @param var2 - input array 2
     * @return output array
     */
    public double[] process(double[] var1, double[] var2) {
        return process(var1, var2, 1);
    }

    /**
     * Recursive BitonicSort method
     * @param start - start index
     * @param n - length of the elements in recursive call
     * @param dir - direction of merge
     */
    public void BitonicSort(int start, int n, int dir) {
        if (n > 1) {
            int mid = n / 2;
            BitonicSort(start, mid, 1);
            BitonicSort(start + mid, mid, 0);
            BitonicMerge(start, n, dir);
        }
    }

    /**
     * Merges the two input arrays and sets up the output array
     * @param var1 - input array 1
     * @param var2 - input array 2
     */
    public void Merge(double[] var1, double[] var2) {
        mergedSequence = new double[output_size];

        int i = 0;
        int j = size - 1;

        // Add first array into mergedSequence
        for (i = 0; i < size; i++) {
            mergedSequence[i] = var1[i];
        }

        // Add second array into mergedSequence in reverse order
        while (i < output_size && j > 0) {
            mergedSequence[i++] = var2[j--];
        }
    }

    /**
     * BitonicMerge, recursively splits the arrays into 2 Bitonic  Sequences
     * @param start - start index
     * @param n - number of elements in the recursive call
     * @param dir - direction of merge
     */
    public void BitonicMerge(int start, int n, int dir)
    {
        if (n>1)
        {
            int mid = n/2;
            for (int i=start; i<start+mid; i++) {
                compareAndSwap(i, i + mid, dir);
            }
            BitonicMerge(start, mid, dir);
            BitonicMerge(start + mid, mid, dir);
        }
    }

    /**
     * Compares and swaps elements in the array, comparison based on direction
     * @param i - index of first element to be swapped
     * @param j - index of last element to be swapped
     * @param dir - direction of merge
     */
    public void compareAndSwap(int i, int j, int dir) {
        if ( (mergedSequence[i] > mergedSequence[j] && dir == 1) ||
                (mergedSequence[i] < mergedSequence[j] && dir == 0))
        {
            // Swapping elements
            double temp = mergedSequence[i];
            mergedSequence[i] = mergedSequence[j];
            mergedSequence[j] = temp;
        }
    }

    /**
     * Poll and wait for 100ms
     * Only when we have fetched a value, we start further processing
     * fetch the next array from the other queue
     * Call Process, include direction descending if its a named thread
     * Write the result to output queue
     * Catch any InterruptedException
     */
    @Override
    public void run() {
        while (true) {
            try {
                double[] array1 = input1.poll(100, TimeUnit.MILLISECONDS);
                if(array1 != null) {
                    double[] array2 = input2.poll(100, TimeUnit.MILLISECONDS);
                    double[] result = name != null  && name.equalsIgnoreCase("descending")
                            ? process(array1, array2, 0)
                            : process(array1, array2);
                    output.offer(result, 100, TimeUnit.MILLISECONDS);
                }
            } catch (InterruptedException e) {
                continue;
            }
        }
    }
}
