import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;

class BitonicPipeline {
    static int N = 1 << 22;

    public static void main(String args[]) {
        // Initial Setup - Thread Arrays, rgThreadPool contains threads for RandomNumberGenerator and soThreadPool contains threads for StageOne
        Thread[] rgThreadPool = new Thread[4]; // Holds 4 RandomNumberGenerator Threads
        Thread[] soThreadPool = new Thread[4]; // Holds 4 StageOne Threads

        SynchronousQueue<double[]> soOutList[] = new SynchronousQueue[4];

        for(int i = 0; i < 4; i++) {
            SynchronousQueue<double[]> rgOut = new SynchronousQueue<>();
            rgThreadPool[i] =  new Thread(new RandomArrayGenerator(N/4, rgOut));

            SynchronousQueue<double[]> soOut = new SynchronousQueue<>();
            soOutList[i] = soOut;
            soThreadPool[i] = new Thread(new StageOne(rgOut, soOut));
        }

        ArrayList<double[]> failed = new ArrayList<double[]>();

        SynchronousQueue<double[]> bs1 = new SynchronousQueue<>(); // Input1 for finalStage, Output from BitonicStage Thread V
        SynchronousQueue<double[]> bs2 = new SynchronousQueue<>(); // Input2 for finalStage, Output from BitonicStage Thread VI
        SynchronousQueue<double[]> bsFinal = new SynchronousQueue<>(); // Output for final BitonicSorter Thread

        Thread bsThread1 = new Thread(new BitonicStage(soOutList[0], soOutList[1], bs1, N/4));
        // Thread VI that passes descending for the order.
        Thread bsThread2 = new Thread(new BitonicStage(soOutList[2], soOutList[3], bs2, "descending", N/4));
        Thread bsFinalThread = new Thread(new BitonicStage(bs1, bs2, bsFinal, N/2));

        // Start all threads other than Random Number Generators.

        for(Thread t : soThreadPool) {
            t.start();
        }
        bsThread1.start();
        bsThread2.start();
        bsFinalThread.start();

        long start = System.currentTimeMillis();
        int TIME_ALLOWED = 10;
        boolean before = true;
        int work = 0;
        int timeout = 3;

        while (System.currentTimeMillis() < start + TIME_ALLOWED * 1000) {
            // Do Once - Start RandomNumberGenerator threads
            if (before) {
                for(Thread t : rgThreadPool) {
                    t.start();
                }
                before = false;
            }

            try {
                //Poll for array from final Synchronous Queue
                double[] ult = bsFinal.poll(timeout * 1000, TimeUnit.MILLISECONDS);
                if (!RandomArrayGenerator.isSorted(ult) && N != ult.length) {
                    // return;
                } else {
                    work++; // Increment if array not null and passes checks - Throughput
                }
            } catch(Exception e) {
                System.out.println("Exception : " + e.toString());
            }
        }
        // Stop the RandomNumberGeneration threads.
        for(Thread t : rgThreadPool) {
            t.interrupt();
        }
        System.out.println("sorted " + work + " arrays (each: " + N + " doubles) in "
                + TIME_ALLOWED + " seconds");

        // Main Thread exit, stops all child threads as well
        System.exit(0);
    }
}
